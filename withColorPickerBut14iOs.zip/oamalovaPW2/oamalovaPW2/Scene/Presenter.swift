import UIKit

final class Presenter: PresentationLogic {
    
    weak var view: WishMakerViewController?
    
    func presentStart(_ request: Model.Start.Response) {
        view?.displayStart()
    }
    
    func presentOther(_ request: Model.Other.Response) {
        view?.displayOther()
    }
    
    func routeTo() {
        view?.navigationController?.pushViewController(UIViewController(), animated: true)
    }
    
    
}
