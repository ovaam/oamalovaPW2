protocol BuissnesLogic {
    func loadStart(_ request: Model.Start.Request)
    func loadOther(_ request: Model.Other.Request)
}

protocol PresentationLogic {
    func presentStart(_ request: Model.Start.Response)
    func presentOther(_ request: Model.Other.Response)
    
    func routeTo()
}
