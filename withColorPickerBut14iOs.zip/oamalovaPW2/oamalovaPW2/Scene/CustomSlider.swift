import UIKit

// MARK: - CustomSlider
final class CustomSlider: UIView {
    
    // MARK: - Constants
    static var titleViewTop: Double = 10
    static var titleViewLeft: Double = 20
    static var sliderBottom: Double = 10
    
    // MARK: - Properties
    var valueChanged: ((Double) -> Void)?
    
    //MARK: - Fields
    var slider = UISlider()
    var titleView = UILabel()
    
    // MARK: - Initializator
    init(title: String, min: Double, max: Double) {
        super.init(frame: .zero)
        titleView.text = title
        slider.maximumValue = Float(max)
        slider.minimumValue = Float(min)
        slider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
        setupUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Private Methods
    private func setupUI() {
        backgroundColor = .white
        translatesAutoresizingMaskIntoConstraints = false
        
        for view in [slider, titleView] {
            addSubview(view)
            view.translatesAutoresizingMaskIntoConstraints = false
        }
        
        titleView.pinCenterX(to: centerXAnchor)
        titleView.pinTop(to: topAnchor, CustomSlider.titleViewTop)
        titleView.pinLeft(to: leadingAnchor, CustomSlider.titleViewLeft)
        
        slider.pinTop(to: titleView.bottomAnchor)
        slider.pinCenterX(to: centerXAnchor)
        slider.pinBottom(to: bottomAnchor, CustomSlider.sliderBottom)
        slider.pinLeft(to: leadingAnchor, CustomSlider.titleViewLeft)
    }
    
    @objc
    private func sliderValueChanged() {
        valueChanged?(Double(slider.value))
        
    }
}
