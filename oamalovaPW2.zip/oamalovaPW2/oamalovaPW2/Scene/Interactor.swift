final class Interactor: BuissnesLogic {
    
    private let presenter: PresentationLogic
    
    init(presenter: PresentationLogic) {
        self.presenter = presenter
    }
    
    func loadStart(_ request: Model.Start.Request) {
        presenter.presentStart(Model.Start.Response())
    }
    
    func loadOther(_ request: Model.Other.Request) {
        presenter.presentOther(Model.Other.Response())
    }
}
