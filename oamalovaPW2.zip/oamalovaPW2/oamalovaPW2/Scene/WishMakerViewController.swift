import UIKit

// MARK: - Constants
enum Constants {
    static let titleSize: CGFloat = 32
    static let titleLeft: Double = 100
    static let titleTop: Double = 20
    
    static let descriptionSize: CGFloat = 15
    static let descriptionTop: Double = 10
    
    static let sliderMin: Double = 0
    static let sliderMax: Double = 1
    
    static let redString: String = "Red"
    static let greenString: String = "Green"
    static let blueString: String = "Blue"
    
    static let stackRadius: Double = 20
    static let stackBottom: Double = 50
    static let stackLeading: Double = 20
    
    static let buttonCornerRadius: Double = 15
    static let buttonBottom: Double = 40
    static let buttonHeight: Double = 50
    static let buttonWidth: Double = 100
    
    static let slidersButtonBottom: Double = 20
    static let slidersButtonLeft: Double = 30
    static let slidersButtonHeight: Double = 30
    static let slidersButtonWidth: Double = 150
}

// MARK: - ViewController
final class WishMakerViewController: UIViewController {
    // MARK: - Fields
    private let titleLabel = UILabel()
    private let descriptionLabel = UILabel()
    private let button = UIButton(type: .system)
    private let slidersButton = UIButton(type: .system)
    private let stack = UIStackView()
    
    // MARK: - Properties
    private let interactor: BuissnesLogic
    
    static var formatHex = "%06X"
    var red: Float = 0.0
    var green: Float = 0.0
    var blue: Float = 0.0
    var alpha: Float = 1.0
    
    // MARK: - Initializators
    init(interactor: BuissnesLogic) {
        self.interactor = interactor
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        interactor.loadStart(Model.Start.Request())
    }
    
    // MARK: - Public methods
    func displayStart() {
        view.backgroundColor = .systemPink
        setTitle()
        setSliders()
        SetRandomedButton()
    }

    func displayOther() {
        view.backgroundColor = .systemPink
        setTitle()
        setSliders()
        SetRandomedButton()
    }
    
// MARK: - Private methods
    
    // MARK: - Set Title
    private func setTitle() {
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.text = "WishMaker"
        titleLabel.font = UIFont.systemFont(ofSize: Constants.titleSize)
        titleLabel.textColor = .white
        
        view.addSubview(titleLabel)
        
        titleLabel.pinCenterX(to: view.centerXAnchor)
        titleLabel.pinLeft(to: view.leadingAnchor, Constants.titleLeft)
        titleLabel.pinTop(to: view.safeAreaLayoutGuide.topAnchor, Constants.titleTop)
        
        setDescription()
    }
    
    private func setDescription() {
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.text = "This app can change it`s color in different ways \n according to your desire"
        descriptionLabel.numberOfLines = 2
        descriptionLabel.textAlignment = .center
        descriptionLabel.textColor = .white
        descriptionLabel.font = UIFont.systemFont(ofSize: Constants.descriptionSize)
        
        view.addSubview(descriptionLabel)
        
        descriptionLabel.pinCenterX(to: view.centerXAnchor)
        descriptionLabel.pinTop(to: titleLabel.bottomAnchor, Constants.descriptionTop)
    }
    
    // MARK: - Set Sliders
    private func setSliders() {
        SetSlidersButton()
   
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        
        view.addSubview(stack)
        stack.layer.cornerRadius = Constants.stackRadius
        stack.clipsToBounds = true
        
        let sliderRed = CustomSlider(title: Constants.redString, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderGreen = CustomSlider(title: Constants.greenString, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderBlue = CustomSlider(title: Constants.blueString, min: Constants.sliderMin, max: Constants.sliderMax)
        
        for slider in [sliderRed, sliderGreen, sliderBlue] {
            stack.addArrangedSubview(slider)
        }
        
        stack.pinHorizontal(to: view, Constants.stackLeading)
        stack.pinBottom(to: view.bottomAnchor, Constants.stackBottom)
        
        sliderRed.valueChanged = { [weak self] value in self?.GetRedS(value: value) }
        sliderGreen.valueChanged = { [weak self] value in self?.GetGreenS(value: value) }
        sliderBlue.valueChanged = { [weak self] value in self?.GetBlueS(value: value) }
        
    }
    private func GetRedS(value: Double) {
        red = Float(value)
        SetColor()
    }
    
    private func GetGreenS(value: Double) {
        green = Float(value)
        SetColor()
    }
    
    private func GetBlueS(value: Double) {
        blue = Float(value)
        SetColor()
    }
    
    private func SetColor() {
        view.backgroundColor = UIColor(_colorLiteralRed: red, green: green, blue: blue, alpha: alpha)
    }
    
    // MARK: - Random button
    private func SetRandomedButton() {
        button.setTitle("Random", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(button)
        
        button.pinBottom(to: stack.topAnchor, Constants.buttonBottom)
        button.pinCenterX(to: view.centerXAnchor)
        
        button.setHeight(Constants.buttonHeight)
        button.setWidth(Constants.buttonWidth)
        
        button.backgroundColor = .white
        button.layer.cornerRadius = Constants.buttonCornerRadius
        button.tintColor = .black
        
        button.addTarget(self, action: #selector(GetRandomHex), for: .touchUpInside)
    }
    
    @objc private func GetRandomHex() {
        let randomHex = String(format: WishMakerViewController.formatHex, arc4random_uniform(0xFFFFFF))
        if stack.isHidden == false {
            stack.isHidden.toggle()
        }
        view.backgroundColor = UIColor(hex: randomHex)
    }
    
    // MARK: - Show/Hide button
    private func SetSlidersButton() {
        slidersButton.setTitle("show/hide sliders", for: .normal)
        slidersButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(slidersButton)
        
        slidersButton.backgroundColor = .darkGray
        slidersButton.layer.cornerRadius = Constants.buttonCornerRadius
        slidersButton.tintColor = .black
        
        slidersButton.pinBottom(to: view.bottomAnchor, Constants.slidersButtonBottom)
        slidersButton.pinCenterX(to: view.centerXAnchor)
        slidersButton.setHeight(Constants.slidersButtonHeight)
        slidersButton.setWidth(Constants.slidersButtonWidth)
        
        slidersButton.addTarget(self, action: #selector(HideShowSliders), for: .touchUpInside)
    }
    @objc private func HideShowSliders() {
        stack.isHidden.toggle()
        SetColor()
    }
}
// MARK: - Extension
extension UIColor {
    static var maxHex = 255.0
    static var sixteen = 16
    static var eight = 8
    
    convenience init?(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        let lenght = hexSanitized.count
        
        var rgb: UInt64 = 0
        var r: CGFloat = 0.0
        var g: CGFloat = 0.0
        var b: CGFloat = 0.0
        let a: CGFloat = 1.0
        
        guard Scanner(string: hexSanitized).scanHexInt64(&rgb) else {return nil}
        
        if lenght == 6 {
            r = CGFloat((rgb & 0xFF0000) >> Self.sixteen) / Self.maxHex
            g = CGFloat((rgb & 0x00FF00) >> Self.eight) / Self.maxHex
            b = CGFloat(rgb & 0x0000FF) / Self.maxHex
        } else {
            return nil
        }
        
        self.init(red: r, green: g, blue: b, alpha: a)
    }
}
