//
//  Protocols.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 28.10.2024.
//

protocol BuissnesLogic {
    func loadStart(_ request: Model.Start.Request)
    func loadOther(_ request: Model.Other.Request)
}

protocol PresentationLogic {
    func presentStart(_ request: Model.Start.Response)
    func presentOther(_ request: Model.Other.Response)
    
    func routeTo()
}
