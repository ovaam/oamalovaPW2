//
//  Presenter.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 28.10.2024.
//

import UIKit

final class Presenter: PresentationLogic {
    
    weak var view: WishMakerViewController?
    
    func presentStart(_ request: Model.Start.Response) {
        view?.displayStart()
    }
    
    func presentOther(_ request: Model.Other.Response) {
        view?.displayOther()
    }
    
    func routeTo() {
        view?.navigationController?.pushViewController(UIViewController(), animated: true)
    }
    
    
}
