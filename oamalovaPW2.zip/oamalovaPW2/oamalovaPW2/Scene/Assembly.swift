import UIKit

enum Assembly {
    static func build() -> UIViewController {
        let presenter = Presenter()
        let interactor = Interactor(presenter: presenter)
        let view = WishMakerViewController(interactor: interactor)
        presenter.view = view
        return view
    }
}
