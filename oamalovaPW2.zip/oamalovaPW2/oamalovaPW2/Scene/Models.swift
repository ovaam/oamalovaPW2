//
//  Models.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 28.10.2024.
//

enum Model {
    enum Start {
        struct Request {}
        struct Response {}
        struct ViewModel {}
    }
    
    enum Other {
        struct Request {}
        struct Response {}
        struct ViewModel {}
    }
}
